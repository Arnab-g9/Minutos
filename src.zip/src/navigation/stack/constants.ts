export const ScreenNames = {
    DASHBOARD_SCREEN: 'DashboardScreen',
    HOME_SCREEN: 'HomeScreen',
    PRODUCT_DETAILS: 'ProductDetailsScreen',
    CART_SCREEN: 'CartScreen',
    LOGIN_SCREEN: 'LoginScreen',
    CATEGORY_SCREEN: 'CategorieScreen',
    PROFILE_SCREEN: "ProfileScreen",
    OTP_SCREEN: 'OtpScreen'
}