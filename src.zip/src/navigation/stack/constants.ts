export const ScreenNames = {
    DASHBOARD_SCREEN: 'DashboardScreen',
    PRODUCT_DETAILS: 'ProductDetailsScreen',
    CART_SCREEN: 'CartScreen'
}