export const IconsName = {
    userIcon: "user",
    orderIcon: 'shopping-bag',
    supportIcon: 'support-agent',
    profileIcon: 'circle-user',
    rightArrowIcon: 'chevron-right',
    logoutIcon: 'logout'
}