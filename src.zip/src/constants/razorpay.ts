/**
 * Razorpay configuration
 * Replace with your Razorpay API Key from https://dashboard.razorpay.com/app/keys
 * Use rzp_test_xxx for test mode, rzp_live_xxx for production
 */
export const RAZORPAY_KEY_ID = 'rzp_test_SIWGlQWV2DxtWg';
