import { ImageSource } from "../../../constants/assets/Images";

interface ICategory {
    image: any,
    name: string,
}

export const CategoryMockData: ICategory[] = [
    {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    },
    {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    }, {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    }, {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    }, {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    }, {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    }, {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    }, {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    }, {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    }, {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    }, {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    }, {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    }, {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    }, {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    }, {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    }, {
        image: ImageSource.category1,
        name: "cold Drinks & Juices",
    },
]