import { StyleSheet } from 'react-native'
import React from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'

const CheckoutScreen = () => {
  return (
  <SafeAreaView edges={["bottom"]} style={{flex:1}}>

  </SafeAreaView>
  )
}

export default CheckoutScreen

const styles = StyleSheet.create({})